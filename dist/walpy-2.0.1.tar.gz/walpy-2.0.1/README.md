# Readme walpy
Walpy is a general purpose package containing '30-second-functions'.
