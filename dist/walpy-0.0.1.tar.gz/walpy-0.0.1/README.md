# Readme walpy
In this notebook I have writen general (short) functions for every day use, which are written to a separate python script. For this reason every function can be imported from the repo separately. There is also a general file containing all functions. The primary usage would be in data science work, however the use cases could be more comprehensive.
